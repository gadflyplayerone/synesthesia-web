
import { useEffect, useRef, useState } from "react";
import type { MicAnalyser } from "../audio/useMicAnalyser";
import { detectPitchACF, simpleCepstrumPitch, predictNextMidi, midiToNoteName, midiToFreq } from "../audio/pitch";
import { Boid, BoidParams, makeBoids, stepBoids, drawBoids } from "../visuals/Boids";
import { Sparkle, burstSparkles, stepSparkles, drawSparkles } from "../visuals/Sparkles";

type Props = { analyser: MicAnalyser; className?: string };

type Swarm = {
  boids: Boid[];
  hueBase: number; // base hue that drifts
  life: number;    // 0..1 fade
  alive: boolean;
  targetPhase: number; // to spread targets
};

function clamp01(v:number){ return Math.max(0, Math.min(1, v)); }
function lerp(a:number,b:number,t:number){ return a + (b-a)*t; }

export default function VisualizerPro({ analyser, className }: Props){
  const canvasRef = useRef<HTMLCanvasElement|null>(null);
  const [fps, setFps] = useState(0);
  const [debugOpen, setDebugOpen] = useState(false);
  const [combo, setCombo] = useState(true); // combine swarm + orb+rays
  const [mode, setMode] = useState<"SWARM"|"ORB"|"RAYS">("SWARM");

  // multi-swarm state
  const swarmsRef = useRef<Swarm[]>([]);
  const sparksRef = useRef<Sparkle[]>([]);
  const boidParams: BoidParams = { count: 120, maxSpeed: 2.4, align: 0.06, coh: 0.012, sep: 0.002, range: 60 };

  // audio buffers
  const fftRef = useRef<Float32Array|null>(null);
  const fftSmoothedRef = useRef<Float32Array|null>(null);
  const timeRef = useRef<Uint8Array|null>(null);
  const midiHist = useRef<number[]>([]);
  const lastBeat = useRef(0);
  const fluxPrev = useRef<Float32Array|null>(null);

  // prediction accuracy stats
  const predQueue = useRef<number[]>([]);
  const errorMAE = useRef(0);
  const errorCount = useRef(0);

  // mini-graphs
  const mini1 = useRef<HTMLCanvasElement|null>(null);
  const mini2 = useRef<HTMLCanvasElement|null>(null);
  const mini3 = useRef<HTMLCanvasElement|null>(null);
  const mini4 = useRef<HTMLCanvasElement|null>(null);

  useEffect(()=>{
    const c = canvasRef.current!;
    const ctx = c.getContext("2d")!;
    let W = c.width = c.clientWidth || window.innerWidth;
    let H = c.height = c.clientHeight || window.innerHeight;

    const onResize = ()=>{
      W = c.width = c.clientWidth || window.innerWidth;
      H = c.height = c.clientHeight || window.innerHeight;
    };
    window.addEventListener("resize", onResize);

    // initial swarms (2..5)
    function spawnSwarm(): Swarm {
      const hueBase = Math.random()*360;
      const s: Swarm = {
        boids: makeBoids(W,H, Math.floor(boidParams.count*(0.6+Math.random()*0.8))),
        hueBase,
        life: 0,
        alive: true,
        targetPhase: Math.random()*Math.PI*2
      };
      // colorize boids near hueBase
      s.boids.forEach((b,i)=> b.hue = hueBase + (i%20)*2);
      return s;
    }
    swarmsRef.current = [];
    const initial = Math.floor(2 + Math.random()*3); // 2-4
    for (let i=0;i<initial;i++) swarmsRef.current.push(spawnSwarm());

    let last = performance.now();
    let raf = 0;

    const loop = ()=>{
      raf = requestAnimationFrame(loop);
      const now = performance.now();
      const dt = (now - last)/1000;
      last = now;
      setFps(prev => lerp(prev, 1/Math.max(1e-3, dt), 0.1));

      ctx.clearRect(0,0,W,H);

      // pull audio
      const a = analyser.node();
      const sr = analyser.sampleRate() ?? 48000;
      if (a){
        if (!fftRef.current) fftRef.current = new Float32Array(analyser.frequencyBinCount());
        if (!fftSmoothedRef.current) fftSmoothedRef.current = new Float32Array(analyser.frequencyBinCount());
        if (!timeRef.current) timeRef.current = new Uint8Array(a.fftSize);
        analyser.getFloatFrequency(fftRef.current);
        analyser.getTimeDomain(timeRef.current);

        // smooth & normalize rays to avoid "cliff"
        const mag = fftRef.current!;
        const sm = fftSmoothedRef.current!;
        let localMax = 1e-6;
        for (let i=0;i<mag.length;i++){
          sm[i] = lerp(sm[i], Math.max(0, mag[i]+140), 0.2); // smooth dB upshift
          if (sm[i] > localMax) localMax = sm[i];
        }
        for (let i=0;i<sm.length;i++) sm[i] = sm[i] / localMax; // normalize 0..1
      }

      const mag = fftRef.current;
      const magN = fftSmoothedRef.current; // normalized [0..1]
      const tdom = timeRef.current;

      // pitch detection + prediction
      let pitchHz: number|null = null, pitchMidi:number|null=null, pitchNote:string|null=null, clarity=0;

      if (tdom){
        const f32 = new Float32Array(tdom.length);
        for (let i=0;i<tdom.length;i++) f32[i] = (tdom[i]-128)/128;
        const r1 = detectPitchACF(f32, sr);
        const r2 = mag ? simpleCepstrumPitch(mag, sr) : {frequency:null,midi:null,note:null,clarity:0};
        const best = (r1.clarity >= r2.clarity) ? r1 : r2;
        pitchHz = best.frequency; pitchMidi = best.midi; pitchNote = best.note; clarity = best.clarity;

        if (pitchMidi && clarity>0.3) {
          midiHist.current.push(pitchMidi);
          if (midiHist.current.length > 128) midiHist.current.shift();
          // evaluate previous prediction error
          if (predQueue.current.length){
            const pred = predQueue.current.shift()!;
            const err = Math.abs(pred - pitchMidi);
            errorMAE.current = (errorMAE.current*errorCount.current + err) / (errorCount.current+1);
            errorCount.current += 1;
          }
        }
      }
      const predicted = predictNextMidi(midiHist.current);
      if (predicted!=null) predQueue.current.push(predicted);

      // spectral flux for beat detection
      let bassEnergy = 0, beat = false, flux = 0;
      if (mag){
        const prev = fluxPrev.current ?? new Float32Array(mag.length);
        let sum=0;
        for (let i=0;i<mag.length;i++){
          const v = Math.max(0, mag[i]+140);
          const diff = Math.max(0, v - prev[i]);
          sum += diff;
          prev[i] = v;
        }
        flux = sum / mag.length;
        fluxPrev.current = prev;
        if (flux > 0.8){
          const since = now - lastBeat.current;
          if (since > 120){
            beat = true;
            lastBeat.current = now;
          }
        }
        // bass band 20-150Hz
        const bins = mag.length;
        const hzPerBin = sr/2 / bins;
        const maxBin = Math.min(bins-1, Math.floor(150/hzPerBin));
        for (let i=0;i<=maxBin;i++){
          bassEnergy += Math.max(0, mag[i]+140);
        }
        bassEnergy /= (maxBin+1);
      }

      // -------------------- DRAW ORB & RAYS --------------------
      const drawOrbAndRays = ()=>{
        const R = Math.min(W,H)*0.18;
        const orbPulse = 0.85 + 0.25*Math.sin(now*0.006 + (bassEnergy*0.03));
        const orbR = R * orbPulse;

        // color cycle tied to pitch/flux
        const hue = ((predicted ?? 60) % 12) * (360/12) + (flux*15);
        const center = `hsla(${hue.toFixed(1)}, 85%, 65%, 1)`;
        const mid = `hsla(${(hue+60)%360}, 75%, 55%, 0.5)`;

        const grd = ctx.createRadialGradient(W/2, H/2, orbR*0.2, W/2, H/2, orbR*1.7);
        grd.addColorStop(0, center);
        grd.addColorStop(0.4, mid);
        grd.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = grd;
        ctx.beginPath(); ctx.arc(W/2,H/2,orbR*1.6,0,Math.PI*2); ctx.fill();

        // strobe outline
        const strobe = (Math.sin(now*0.02) > 0.92) ? 1 : 0;
        if (strobe){
          ctx.strokeStyle = `hsla(${hue}, 90%, 70%, 0.9)`;
          ctx.lineWidth = 2;
          ctx.beginPath(); ctx.arc(W/2,H/2,orbR*1.1, 0, Math.PI*2); ctx.stroke();
        }

        // rays normalized and continuous
        if (magN){
          const N = magN.length;
          ctx.save();
          ctx.translate(W/2,H/2);
          const base = orbR*1.1;
          for (let k=0;k<N;k++){
            const val = clamp01(magN[k]); // 0..1 normalized
            const angle = (k/N)*Math.PI*2 + now*0.0003;
            const r1 = base;
            const r2 = base + val*140;
            // gradient color scheme aligned to original palette (brand/accent)
            const c = `hsla(${(hue + (k/N)*90)%360}, 85%, ${50 + val*20}%, ${0.45 + val*0.4})`;
            ctx.strokeStyle = c;
            ctx.lineWidth = 1.1;
            ctx.beginPath();
            ctx.moveTo(Math.cos(angle)*r1, Math.sin(angle)*r1);
            ctx.lineTo(Math.cos(angle)*r2, Math.sin(angle)*r2);
            ctx.stroke();
          }
          ctx.restore();
        }
      };

      // -------------------- DRAW SWARMS (2-5 swarms) --------------------
      const drawSwarms = ()=>{
        // manage spawning/despawning
        if (swarmsRef.current.length < 2 || (swarmsRef.current.length < 5 && Math.random()<0.01)){
          swarmsRef.current.push(spawnLike());
        }
        if (swarmsRef.current.length > 2 && Math.random()<0.004){
          // mark a random swarm to fade out
          const idx = Math.floor(Math.random()*swarmsRef.current.length);
          swarmsRef.current[idx].alive = false;
        }

        const pred = predicted ?? 60;
        const thetaBase = (pred/12)*Math.PI*2 + now*0.0006;

        // mild attraction between swarms ("swarms of swarms")
        const centers = swarmsRef.current.map(s=>centerOf(s.boids));
        for (let i=0;i<swarmsRef.current.length;i++){
          const s = swarmsRef.current[i];
          s.hueBase = (s.hueBase + 0.05) % 360; // slow hue drift
          s.life = clamp01( lerp(s.life, s.alive ? 1 : 0, 0.02) );
          const radius = Math.min(W,H)*0.25 + Math.sin(now*0.001 + s.targetPhase)*20;
          const target = {
            x: W/2 + Math.cos(thetaBase + s.targetPhase)*radius,
            y: H/2 + Math.sin(thetaBase + s.targetPhase)*radius
          };

          // inter-swarm coupling
          let tx = target.x, ty = target.y;
          for (let j=0;j<centers.length;j++){
            if (i===j) continue;
            tx = lerp(tx, centers[j].x, 0.02);
            ty = lerp(ty, centers[j].y, 0.02);
          }

          stepBoids(s.boids, W,H, boidParams, {x:tx, y:ty}, Math.min(2, bassEnergy*0.02));

          // continuous subtle sparkles around boids
          if (Math.random() < 0.6){
            const b = s.boids[Math.floor(Math.random()*s.boids.length)];
            burstSparkles(sparksRef.current, b.x, b.y, 3, 0.2 + Math.min(1.5, bassEnergy*0.01));
          }

          // draw with alpha per swarm life and palette aligned to original
          ctx.save();
          ctx.globalAlpha = 0.6 * s.life;
          drawBoids(ctx, s.boids.map(b=>{
            // nudge boid hues toward two-tone brand/accent scheme
            b.hue = (s.hueBase + (b.hue*0.1)) % 360;
            return b;
          }));
          ctx.restore();
        }

        // beat-synced sparkles burst at center
        if (Math.random()<0.2 || flux>0.8){
          burstSparkles(sparksRef.current, W/2, H/2, 8, Math.min(2, bassEnergy*0.02));
        }
        stepSparkles(sparksRef.current, W,H);
        drawSparkles(ctx, sparksRef.current);
      };

      function centerOf(boids:Boid[]){ 
        let x=0,y=0; for(const b of boids){ x+=b.x; y+=b.y; } 
        const n = Math.max(1, boids.length); 
        return {x:x/n, y:y/n}; 
      }
      function spawnLike(): Swarm {
        const hueBase = Math.random()*360;
        const s: Swarm = {
          boids: makeBoids(W,H, Math.floor(boidParams.count*(0.6+Math.random()*0.8))),
          hueBase, life: 0, alive: true, targetPhase: Math.random()*Math.PI*2
        };
        s.boids.forEach((b,i)=> b.hue = hueBase + (i%32)*1.7);
        return s;
      }

      // draw combined or modes
      if (combo){
        drawOrbAndRays();
        drawSwarms();
      } else {
        if (mode==="ORB" || mode==="RAYS") drawOrbAndRays();
        if (mode==="SWARM") drawSwarms();
      }

      // -------------------- DEBUG: FFT orders + stats --------------------
      if (debugOpen){
        const pad = 8, w = 220, h = 60;
        const x0 = 12, y0 = 90;
        ctx.save();
        ctx.fillStyle = "rgba(8,11,31,0.85)";
        ctx.strokeStyle = "rgba(255,255,255,0.15)";
        ctx.lineWidth = 1;
        const panelH = h*4 + pad*6 + 90;
        ctx.fillRect(x0-6, y0-40, w+16, panelH);
        ctx.strokeRect(x0-6, y0-40, w+16, panelH);

        ctx.fillStyle = "rgba(255,255,255,0.9)";
        ctx.font = "12px ui-sans-serif, system-ui";
        const noteText = pitchNote ? `${pitchNote}  ${pitchHz?.toFixed(1)}Hz  q=${clarity.toFixed(2)}` : "—";
        const mae = errorCount.current ? (errorMAE.current).toFixed(2) : "—";
        ctx.fillText(`Pitch: ${noteText}`, x0, y0-20);
        ctx.fillText(`Pred Next: ${predicted!=null? midiToNoteName(predicted): "—"}  MAE(semitones): ${mae}`, x0, y0-5);
        ctx.fillText(`FPS ${fps.toFixed(0)}  Beat ${flux.toFixed(2)}`, x0, y0+10);

        // Draw mini graphs: order1..order4
        drawMini(mini1.current, ctx, x0, y0+pad*2, w, h, fftRef.current, "FFT (Order 1)");
        // Order 2: cepstrum from simpleCepstrumPitch (we recompute quick-like)
        const order2 = mag ? computeCepstrum(mag) : null;
        drawMini(mini2.current, ctx, x0, y0+pad*2+h+pad, w, h, order2, "Order 2 (Cepstrum)");
        // Order 3: FFT of order2 magnitude
        const order3 = order2 ? fftMag(order2) : null;
        drawMini(mini3.current, ctx, x0, y0+pad*2+2*(h+pad), w, h, order3, "Order 3 (FFT of Cep)");
        // Order 4: FFT of order3 magnitude
        const order4 = order3 ? fftMag(order3) : null;
        drawMini(mini4.current, ctx, x0, y0+pad*2+3*(h+pad), w, h, order4, "Order 4");

        ctx.restore();
      }

      function drawMini(_cv:HTMLCanvasElement|null, c:CanvasRenderingContext2D, x:number,y:number,w:number,h:number, data:Float32Array|null, label:string){
        c.save();
        c.strokeStyle = "rgba(255,255,255,0.15)";
        c.strokeRect(x-2,y-2,w+4,h+4);
        c.fillStyle = "rgba(255,255,255,0.08)";
        c.fillRect(x,y,w,h);
        c.fillStyle = "rgba(255,255,255,0.85)";
        c.font = "11px ui-sans-serif, system-ui";
        c.fillText(label, x+6, y+14);
        if (data){
          c.beginPath();
          for (let i=0;i<w;i++){
            const idx = Math.floor(i / w * data.length);
            const v = data[idx];
            const nv = isFinite(v) ? (v) : 0;
            // normalize each graph independently
            // get local min/max
          }
          // draw normalized polyline
          let min=Infinity, max=-Infinity;
          for (let i=0;i<data.length;i++){ const v = data[i]; if (isFinite(v)) { if(v<min)min=v; if(v>max)max=v; } }
          const range = (max-min) || 1;
          c.beginPath();
          for (let i=0;i<w;i++){
            const idx = Math.floor(i / w * data.length);
            const nv = (data[idx]-min)/range;
            const yy = y + h - nv*h;
            const xx = x + i;
            if (i===0) c.moveTo(xx, yy); else c.lineTo(xx, yy);
          }
          c.strokeStyle = "rgba(255,240,200,0.9)";
          c.lineWidth = 1;
          c.stroke();
        }
        c.restore();
      }

      function computeCepstrum(mag: Float32Array): Float32Array {
        const N = mag.length;
        const logMag = new Float32Array(N);
        for (let i=0;i<N;i++) logMag[i] = Math.log(1e-12 + Math.max(0, mag[i]+140));
        // cosine DFT
        const cep = new Float32Array(N);
        for (let k=0;k<N;k++){
          let sum = 0;
          for (let n=0;n<N;n++) sum += logMag[n]*Math.cos((2*Math.PI*k*n)/N);
          cep[k] = sum;
        }
        return cep;
      }
      function fftMag(signal: Float32Array): Float32Array {
        const N = signal.length;
        const out = new Float32Array(N);
        for (let k=0;k<N;k++){
          let re=0, im=0;
          for (let n=0;n<N;n++){
            const ang = -2*Math.PI*k*n/N;
            re += signal[n]*Math.cos(ang);
            im += signal[n]*Math.sin(ang);
          }
          out[k] = Math.hypot(re,im);
        }
        return out;
      }

    };

    raf = requestAnimationFrame(loop);
    return ()=>{ cancelAnimationFrame(raf); window.removeEventListener("resize", onResize); }
  }, [analyser, combo, mode, debugOpen]);

  return (
    <div className={className ?? ""} style={{position:"relative", width:"100%", height:"100%"}}>
      <canvas ref={canvasRef} style={{width:"100%", height:"100%"}} />
      <div className="mode-toggle" style={{right: debugOpen ? 240 : 12}}>
        <button onClick={()=>setCombo(!combo)}>{combo ? "Separate Modes" : "Combine"}</button>
        <button onClick={()=>setMode("SWARM")}>Swarm</button>
        <button onClick={()=>setMode("RAYS")}>Orb+Rays</button>
        <button onClick={()=>setMode("ORB")}>Orb Only</button>
        <button onClick={()=>setDebugOpen(!debugOpen)}>{debugOpen?"Hide Debug":"Show Debug"}</button>
      </div>
    </div>
  )
}
